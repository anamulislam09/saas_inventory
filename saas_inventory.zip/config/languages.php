<?php
    return [
        'en'=>'English',
        'bn'=>'Bangla',
    ];
?>